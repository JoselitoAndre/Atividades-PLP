package diamante;

public abstract class Cafe {
	
	protected String cafe;
	protected String agua;
	
	
	public Cafe(String cafe, String agua) {
		super();
		this.cafe = cafe;
		this.agua = agua;
	}


	public String getCafe() {
		return cafe;
	}



	public void setCafe(String cafe) {
		this.cafe = cafe;
	}



	public String getAgua() {
		return agua;
	}



	public void setAgua(String agua) {
		this.agua = agua;
	}


	public abstract void preparo();

}
