package diamante;

public class CafeComAcucarELeite extends CafeComAcucar, CafeComLeite  {
	
	
	//O codigo Nao compila devido ao probelma do diamante
	
	
	public void preparo() {
		// TODO Auto-generated method stub
		System.out.println(agua + cafe + leite+ acucar);
	}


}
