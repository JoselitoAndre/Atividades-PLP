package diamante;

public class CafeComLeite extends Cafe{

	private String leite;
	public CafeComLeite(String leite,String cafe, String agua) {
		super(cafe, agua);
		// TODO Auto-generated constructor stub
		this.leite = leite;
	}

	@Override
	public void preparo() {
		// TODO Auto-generated method stub
		System.out.println(agua + cafe + leite);
	}

}
