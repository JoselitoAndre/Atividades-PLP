package diamante;

public class CafeComAcucar extends Cafe{

	private String acucar;
	
	public CafeComAcucar(String acucar, String cafe, String agua) {
		super(cafe, agua);
		// TODO Auto-generated constructor stub
		this.acucar = acucar;
		
	}
	

	public String getAcucar() {
		return acucar;
	}


	public void setAcucar(String acucar) {
		this.acucar = acucar;
	}


	@Override
	public void preparo() {
		// TODO Auto-generated method stub
		
		System.out.println(agua + cafe + acucar);
	}

	
}
